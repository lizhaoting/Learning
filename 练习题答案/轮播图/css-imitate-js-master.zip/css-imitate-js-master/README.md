# css-imitate-js
使用纯css模拟常用js效果
[slider demo浏览地址](https://huruji.github.io/css-imitate-js/slider/index.html)